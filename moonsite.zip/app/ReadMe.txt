

To run the Moonsite Application:

1. Create new react native by running the command:
	react-native init RNapp

2. Copy "src" floder and "package.json" file to the new project
3. Run npm install

4. Run the app by emulator
 or on android device
